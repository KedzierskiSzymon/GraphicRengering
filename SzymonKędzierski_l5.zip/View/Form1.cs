﻿using Common.Structures;
using Library;
using Library.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Color = Library.Color;
using Point = Library.Point;

namespace View
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Print()
        {
            ColorBuffer buffer = new ColorBuffer(400, 600);
            Color bufferColor = new Color(0x0000ff, false);
            Color triangleColor = new Color(0x888888, false);

            Color red = new Color(0xff0000, false);
            Color green = new Color(0x00ff00, false);
            Color blue = new Color(0x0000ff, false);

            buffer.ClearColor(bufferColor);
            buffer.ClearDepth();

            // Primitives definitions
            Point[] trianglePoints = new Point[]
            {
                new Point(0, 0, 0.5f, triangleColor),
                new Point(-1, 0, 0.5f, triangleColor),
                new Point(1, 1, 0.5f, triangleColor),

            };

            Point[] trianglePoints2 = new Point[]
            {
                new Point(-2, -4, 0.5f, red),
                new Point(-5, -4, 0.5f, green),
                new Point(0, 1, 0.5f, blue),

            };

            Point[] trianglePoints3 = new Point[]
{
                new Point(1, 1, 0.5f, red),
                new Point(0, 1, 0.5f, red),
                new Point(1, 2, 0.5f, red),

};
            Triangle triangle = new Triangle(trianglePoints);
            Triangle triangle2 = new Triangle(trianglePoints2);
            Triangle triangle3 = new Triangle(trianglePoints3);

            // Vertex buffer
            VertexProcessor vertexProcessor = new VertexProcessor();
            vertexProcessor.SetPerspective(45, 1, 4, 1000);
            //vertexProcessor.SetLookAt(new Float3(0.0f, 0.0f, 0.0f), new Float3(0.0f, 0.0f, 1), new Float3(0, 1, 0));

            Float3[] p = new Float3[]
{
    triangle2.Points[0].Coordinate,
    triangle2.Points[1].Coordinate,
    triangle2.Points[2].Coordinate
};


            Float3[] r = new Float3[]
{
    triangle.Points[0].Coordinate,
    triangle.Points[1].Coordinate,
    triangle.Points[2].Coordinate
};

            Float3[] s = new Float3[]
{
    triangle3.Points[0].Coordinate,
    triangle3.Points[1].Coordinate,
    triangle3.Points[2].Coordinate
};

            for (int i = 0; i < 100; i++)
                {
                vertexProcessor.Translate(new Float3(i * .2f, 0, 0));
                //vertexProcessor.Rotate(20, new Float3(i, 0, 0));
                //vertexProcessor.Scale(new Float3(1 + i* 0.1f, 1 + i * 0.1f, 1 + i * 0.1f));
                vertexProcessor.Transform();

                //triangle.Points[0].Coordinate = vertexProcessor.Tr(triangle.Points[0].Coordinate);
                //triangle.Points[1].Coordinate = vertexProcessor.Tr(triangle.Points[1].Coordinate);
                //triangle.Points[2].Coordinate = vertexProcessor.Tr(triangle.Points[2].Coordinate);

                triangle2.Points[0].Coordinate = vertexProcessor.Tr(p[0]);
                triangle2.Points[1].Coordinate = vertexProcessor.Tr(p[1]);
                triangle2.Points[2].Coordinate = vertexProcessor.Tr(p[2]);
                vertexProcessor.SetIdentity();

                //float scale = i % 2 == 0 ? .5f : 2;
                float scale = i % 2 == 0 ? -0.5f : 1.2f;

                vertexProcessor.Scale(new Float3(scale, scale, scale));
                vertexProcessor.Transform();

                triangle.Points[0].Coordinate = vertexProcessor.Tr(r[0]);
                triangle.Points[1].Coordinate = vertexProcessor.Tr(r[1]);
                triangle.Points[2].Coordinate = vertexProcessor.Tr(r[2]);
                vertexProcessor.SetIdentity();

                vertexProcessor.Rotate(i * 20, new Float3(0, 0, 1));
                vertexProcessor.Transform();

                triangle3.Points[0].Coordinate = vertexProcessor.Tr(s[0]);
                triangle3.Points[1].Coordinate = vertexProcessor.Tr(s[1]);
                triangle3.Points[2].Coordinate = vertexProcessor.Tr(s[2]);
                vertexProcessor.SetIdentity();


                buffer.Print(triangle);
                buffer.Print(triangle2);
                buffer.Print(triangle3);
                Bitmap b = buffer.GetBitmap();

                if (i == 5)
                    buffer.SaveImage("SzymonKędzierski_l5.png", true);
                pictureBox1.Image = b;
                pictureBox1.Refresh();
                buffer.ClearColor();
                buffer.ClearDepth();
                vertexProcessor.SetIdentity();
                vertexProcessor.Transform();



                // System.Threading.Thread.Sleep(500);
            }



        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void pictureBox1_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            Print();
        }
    }
}
